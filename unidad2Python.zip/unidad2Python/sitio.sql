-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 07-12-2023 a las 18:08:01
-- Versión del servidor: 10.4.28-MariaDB
-- Versión de PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `sitio`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `articulos`
--

CREATE TABLE `articulos` (
  `id_articulo` int(11) NOT NULL,
  `nombre` varchar(255) NOT NULL,
  `descripcion` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `articulos`
--

INSERT INTO `articulos` (`id_articulo`, `nombre`, `descripcion`, `url`) VALUES
(1, 'Procesador I-Core I7', 'Para el buen rendimiento', 'https://imgs.search.brave.com/38W_l7zUG-_ctzj7CfF-ydyuAjvnD2WBTfo5E9EsetM/rs:fit:860:0:0/g:ce/aHR0cHM6Ly9pbWFn/ZXMtbmEuc3NsLWlt/YWdlcy1hbWF6b24u/Y29tL2ltYWdlcy9J/LzUxQXFFa2MyQnVM/LmpwZw');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `juegos`
--

CREATE TABLE `juegos` (
  `id_juego` int(11) NOT NULL,
  `nombre` varchar(255) NOT NULL,
  `descripcion` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `juegos`
--

INSERT INTO `juegos` (`id_juego`, `nombre`, `descripcion`, `url`) VALUES
(2, 'GTV 4', 'Juego Buenoo', 'https://imgs.search.brave.com/OdUJ_ElT_qwzxNgT21Hu4NXgXjiRpKQLbRX8XH2lQxs/rs:fit:860:0:0/g:ce/aHR0cHM6Ly93YWxs/cGFwZXJjYXZlLmNv/bS93cC9CUkNqTnJX/LmpwZw');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `libros`
--

CREATE TABLE `libros` (
  `id` int(11) NOT NULL,
  `nombre` varchar(255) NOT NULL,
  `imagen` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `libros`
--

INSERT INTO `libros` (`id`, `nombre`, `imagen`, `url`) VALUES
(2, 'ANGELA', 'GALVAN.png', 'https://imgs.search.brave.com/gJ3uGZpVXjDdRdfNTb0R42B6mdSZZgE7K21tRLepI58/rs:fit:860:0:0/g:ce/aHR0cHM6Ly93d3cu/ZWNhcnRlbGVyYS5j/b20vY2FydGVsZXMv/NTEwMC81MTUxLzAw/MV9wLmpwZw'),
(3, 'GUADALUPE', 'ALANIS.png', 'https://imgs.search.brave.com/xV2Ecg172rZ3rsWDWBqZ-Y2rZM_fCeFUKXPoKKIeADY/rs:fit:860:0:0/g:ce/aHR0cHM6Ly93d3cu/Y3VlbnRvc2RlcHJp/bmNlc2FzLmNvbS93/cC1jb250ZW50L3Vw/bG9hZHMvMjAxOS8x/Mi9sYS1wcmluY2Vz/YS15LWVsLXNhcG8u/anBn'),
(4, 'SANTIAGO ', 'POOL.PNG', 'https://imgs.search.brave.com/qwCZX-pDoxWZw_N-I7qA72kS4GjzJp7tLP07Quafm9U/rs:fit:500:0:0/g:ce/aHR0cHM6Ly9jZG4u/Y3VsdHVyYWdlbmlh/bC5jb20vZXMvaW1h/Z2VuZXMvdW4tbXVu/ZG8tZmVsaXotY2tl/LmpwZw'),
(5, 'TIAGO', 'MEEE.PNG', 'https://imgs.search.brave.com/WxdeN8aKZY0Lm4JQoinEnRjE_VhfqcXQ9EFS0LeZzcw/rs:fit:500:0:0/g:ce/aHR0cHM6Ly9jZG4u/Y3VsdHVyYWdlbmlh/bC5jb20vZXMvaW1h/Z2VuZXMvZWwtbGli/cm8tbmVncm8tZGUt/bGFzLWhvcmFzLWNr/ZS5qcGc'),
(6, 'JUAN', 'SS.png', 'https://imgs.search.brave.com/FV8k3c_EJEbm7-BGS-gNUINVcsbTssaqQjaSrYLLguk/rs:fit:500:0:0/g:ce/aHR0cHM6Ly9pbWFn/ZXNzbDUuY2FzYWRl/bGxpYnJvLmNvbS9h/L2wvczUvMzUvOTc4/ODQxOTQyMTEzNS53/ZWJw');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `peliculas`
--

CREATE TABLE `peliculas` (
  `id_pelicula` int(11) NOT NULL,
  `nombre` varchar(255) NOT NULL,
  `descripcion` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `peliculas`
--

INSERT INTO `peliculas` (`id_pelicula`, `nombre`, `descripcion`, `url`) VALUES
(5, 'SAW X', 'Pelicula de terror', 'https://imgs.search.brave.com/UuTvmGbMt25IvVH_BPJdijLex_IEbnk8_UcNSdij0_8/rs:fit:860:0:0/g:ce/aHR0cHM6Ly93d3cu/ZGVhcGxhbmV0YS5j/b20vdXBsb2Fkcy8y/MDIzMDgwMS9TYXdY/X1Bvc3Rlcl8yMzAu/anBn');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `articulos`
--
ALTER TABLE `articulos`
  ADD PRIMARY KEY (`id_articulo`);

--
-- Indices de la tabla `juegos`
--
ALTER TABLE `juegos`
  ADD PRIMARY KEY (`id_juego`);

--
-- Indices de la tabla `libros`
--
ALTER TABLE `libros`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `peliculas`
--
ALTER TABLE `peliculas`
  ADD PRIMARY KEY (`id_pelicula`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `articulos`
--
ALTER TABLE `articulos`
  MODIFY `id_articulo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `juegos`
--
ALTER TABLE `juegos`
  MODIFY `id_juego` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `libros`
--
ALTER TABLE `libros`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT de la tabla `peliculas`
--
ALTER TABLE `peliculas`
  MODIFY `id_pelicula` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
