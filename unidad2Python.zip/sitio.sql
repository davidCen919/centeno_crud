-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 06-12-2023 a las 22:22:37
-- Versión del servidor: 10.4.28-MariaDB
-- Versión de PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `sitio`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `libros`
--

CREATE TABLE `libros` (
  `id` int(11) NOT NULL,
  `nombre` varchar(255) NOT NULL,
  `imagen` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `libros`
--

INSERT INTO `libros` (`id`, `nombre`, `imagen`, `url`) VALUES
(2, 'ANGELA', 'GALVAN.png', 'https://imgs.search.brave.com/gJ3uGZpVXjDdRdfNTb0R42B6mdSZZgE7K21tRLepI58/rs:fit:860:0:0/g:ce/aHR0cHM6Ly93d3cu/ZWNhcnRlbGVyYS5j/b20vY2FydGVsZXMv/NTEwMC81MTUxLzAw/MV9wLmpwZw'),
(3, 'GUADALUPE', 'ALANIS.png', 'https://imgs.search.brave.com/xV2Ecg172rZ3rsWDWBqZ-Y2rZM_fCeFUKXPoKKIeADY/rs:fit:860:0:0/g:ce/aHR0cHM6Ly93d3cu/Y3VlbnRvc2RlcHJp/bmNlc2FzLmNvbS93/cC1jb250ZW50L3Vw/bG9hZHMvMjAxOS8x/Mi9sYS1wcmluY2Vz/YS15LWVsLXNhcG8u/anBn'),
(4, 'SANTIAGO ', 'POOL.PNG', 'https://imgs.search.brave.com/qwCZX-pDoxWZw_N-I7qA72kS4GjzJp7tLP07Quafm9U/rs:fit:500:0:0/g:ce/aHR0cHM6Ly9jZG4u/Y3VsdHVyYWdlbmlh/bC5jb20vZXMvaW1h/Z2VuZXMvdW4tbXVu/ZG8tZmVsaXotY2tl/LmpwZw'),
(5, 'TIAGO', 'MEEE.PNG', 'https://imgs.search.brave.com/WxdeN8aKZY0Lm4JQoinEnRjE_VhfqcXQ9EFS0LeZzcw/rs:fit:500:0:0/g:ce/aHR0cHM6Ly9jZG4u/Y3VsdHVyYWdlbmlh/bC5jb20vZXMvaW1h/Z2VuZXMvZWwtbGli/cm8tbmVncm8tZGUt/bGFzLWhvcmFzLWNr/ZS5qcGc'),
(6, 'JUAN', 'SS.png', 'https://imgs.search.brave.com/FV8k3c_EJEbm7-BGS-gNUINVcsbTssaqQjaSrYLLguk/rs:fit:500:0:0/g:ce/aHR0cHM6Ly9pbWFn/ZXNzbDUuY2FzYWRl/bGxpYnJvLmNvbS9h/L2wvczUvMzUvOTc4/ODQxOTQyMTEzNS53/ZWJw'),
(7, 'dado', 'pi.pgn', 'https://imgs.search.brave.com/KR9wLM0TXzi-TPJwUUil8WONEGehjdjciOfC4a5u4Zo/rs:fit:860:0:0/g:ce/aHR0cHM6Ly93d3cu/Y29uYWxpdGVnLnNl/cC5nb2IubXgvMjAy/My9tL1A0UEFBLzAw/MC5qcGc');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `libros`
--
ALTER TABLE `libros`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `libros`
--
ALTER TABLE `libros`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
